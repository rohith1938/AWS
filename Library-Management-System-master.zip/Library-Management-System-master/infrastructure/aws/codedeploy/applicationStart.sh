#!/bin/bash

# Starting tomcat service
sudo systemctl start amazon-cloudwatch-agent.service
sudo systemctl start tomcat.service
