#!/bin/bash

# Stoping tomcat
sudo systemctl stop tomcat.service
sudo systemctl stop amazon-cloudwatch-agent.service